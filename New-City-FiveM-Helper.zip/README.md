# New City — FiveM Helper

A lightweight, responsive FiveM community helper site for **New City**.

## Run locally
Open `index.html` in a browser. No build system or dependencies are required.

## GitHub Pages
1. Create a GitHub repository (for example, `NewCity-Helper`).
2. Upload the files in this folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then save.
6. GitHub will provide your Pages URL.

## Customize
Edit `script.js` to change skills and commands. Edit `index.html` for the navigation and server information. Edit `style.css` to change the visual design.

This project is independently written and does not copy the source code of the reference site.
