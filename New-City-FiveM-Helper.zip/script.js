const skills=[
  {icon:"🚓",name:"Law Enforcement",desc:"Reference information for patrol, communication, traffic stops, and department procedures.",tag:"Public Safety"},
  {icon:"🚑",name:"Medical",desc:"General reference for EMS roleplay, scene response, patient care, and department communication.",tag:"EMS"},
  {icon:"🔧",name:"Mechanic",desc:"General reference for vehicle repair roleplay, shop workflow, and service interactions.",tag:"Civilian"},
  {icon:"🏙️",name:"Civilian",desc:"Helpful information for everyday civilian roleplay, jobs, businesses, and city activities.",tag:"Roleplay"},
  {icon:"📻",name:"Communications",desc:"Radio etiquette, clear callouts, and communication best practices for city departments.",tag:"Radio"},
  {icon:"🧭",name:"New Player",desc:"A quick starting point for learning the city, finding support, and getting comfortable.",tag:"Getting Started"}
];
const commands=[
  ["/help","Open the server help menu"],["/report","Send a support/report request"],["/me","Describe an in-character action"],["/do","Describe a scene or environmental detail"],["/ooc","Out-of-character communication, if enabled"],["/911","Emergency roleplay call, if enabled"]
];
const grid=document.querySelector("#skillGrid"), search=document.querySelector("#skillSearch");
function renderSkills(q=""){grid.innerHTML=skills.filter(s=>(s.name+" "+s.desc+" "+s.tag).toLowerCase().includes(q.toLowerCase())).map(s=>`<article class="card"><div class="icon">${s.icon}</div><h3>${s.name}</h3><p>${s.desc}</p><span class="tag">${s.tag}</span></article>`).join("")||"<p>No skills found.</p>"}
function renderCommands(){document.querySelector("#commandList").innerHTML=commands.map(([c,d])=>`<div class="command"><div><code>${c}</code><span> — ${d}</span></div><button class="copy" data-copy="${c}">Copy</button></div>`).join("")}
search.addEventListener("input",e=>renderSkills(e.target.value)); renderSkills(); renderCommands();
document.addEventListener("click",e=>{if(e.target.matches(".copy")){navigator.clipboard?.writeText(e.target.dataset.copy);e.target.textContent="Copied!";setTimeout(()=>e.target.textContent="Copy",900)}});
document.querySelector("#menuBtn").addEventListener("click",()=>document.querySelector("#nav").classList.toggle("open"));
document.querySelectorAll("nav a").forEach(a=>a.addEventListener("click",()=>document.querySelector("#nav").classList.remove("open")));
